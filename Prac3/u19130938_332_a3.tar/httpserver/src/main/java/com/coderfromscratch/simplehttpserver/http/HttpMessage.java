package com.coderfromscratch.simplehttpserver.http;

public abstract class HttpMessage {



}
