package com.coderfromscratch.simplehttpserver.http;

public enum Operation {
    ADD,SUB,MUL,DIV,NUL,RES;
}
