package com.coderfromscratch.simplehttpserver.http;

public enum HttpMethod {
    GET, HEAD;
}
